# 赞助商与用户福利

[English](SPONSORS.md) | 中文

PPT Master 始终免费开源。以下赞助方共同支持项目的持续维护，并为 PPT Master 用户提供可选福利。赞助不会改变项目不绑定 Provider 的设计：你仍可自由选择任何兼容的 Agent、模型或服务。

希望支持项目或洽谈合作？请查看[赞助合作说明](https://github.com/hugohe3/ppt-master/blob/main/SPONSORING_CN.md)。

## 当前模型推荐

追求最佳效果，语言模型选 **[Kimi K3.1](https://www.kimi.com/code/?aff=ppt-master)**（或 Gemini）驱动流程，搭配 AI 生图模型 **`gpt-image-2.6-sunburst`**（OpenAI）或 **`gemini-nano-banana-2.1`**（Google）。如果模型能力正在拖累产出质量，应先升级驱动模型，而不是削弱工作流或质量要求。

## Kimi

<p align="center">
  <a href="https://www.kimi.com/code/?aff=ppt-master"><img src="https://gcdn.moonshot.cn/growth-cdn/sponsor/kimi-zh.png" alt="Kimi" width="100%"></a>
</p>

感谢 [Kimi](https://www.kimi.com/code/?aff=ppt-master) 赞助 PPT Master。[Kimi K3](https://platform.kimi.com/docs/guide/kimi-k3-quickstart) 是全球首个开源 3T 级模型，拥有原生视觉能力与 100 万 Token 上下文。搭配 PPT Master，K3 可以理解 PDF、DOCX、网页等原始资料，梳理演示逻辑并生成原生可编辑的 PPTX。

**立即体验 [Kimi Code](https://www.kimi.com/code/?aff=ppt-master)（[中文站](https://www.kimi.com/code/?aff=ppt-master)｜[Global](https://www.kimi.ai/code/?aff=ppt-master)），或通过 Kimi 开放平台（[中文站](https://platform.kimi.com?aff=ppt-master)｜[Global](https://platform.kimi.ai?aff=ppt-master)）使用 API。**

## 模型接入合作伙伴

### PackyCode

<a href="https://www.packyapi.ai/register?aff=ppt-master"><img src="https://raw.githubusercontent.com/hugohe3/ppt-master/main/docs/assets/sponsors/packycode.png" alt="PackyCode" width="150"></a>

[PackyCode](https://www.packyapi.ai/register?aff=ppt-master) 提供 Claude Code、Codex、Gemini 等服务的中转接入。通过专属链接注册，并在充值时填写优惠码 **`ppt-master`**，即可享受 9 折优惠。

### APIKEY.FAN

<a href="https://apikey.fan/register?aff=PPT-MASTER"><img src="https://raw.githubusercontent.com/hugohe3/ppt-master/main/docs/assets/sponsors/apikey-fan.png" alt="APIKEY.FAN" width="150"></a>

[APIKEY.FAN](https://apikey.fan/register?aff=PPT-MASTER) 提供 Claude、OpenAI、Gemini 等主流模型的企业级接入服务。通过专属链接注册，最高可享永久充值 95 折优惠。

### RunAPI

<a href="https://runapi.host/register?aff=WMLJ"><img src="https://raw.githubusercontent.com/hugohe3/ppt-master/main/docs/assets/sponsors/runapi.png" alt="RunAPI" width="150"></a>

[RunAPI](https://runapi.host/register?aff=WMLJ) 通过一个 API Key 提供 OpenAI、Claude、Gemini、DeepSeek、Grok 等 150+ 主流模型。通过专属链接注册并联系管理员，即可领取 **¥7 免费额度**。

### ModelGo

<a href="https://modelgo.ai/?utm_source=ppt-master&amp;utm_medium=sponsorship&amp;utm_content=readme02&amp;campaign_id=ppt-master-github&amp;ad_group_id=readme02"><img src="https://raw.githubusercontent.com/hugohe3/ppt-master/main/docs/assets/sponsors/modelgo.svg" alt="ModelGo" width="150"></a>

感谢 ModelGo 赞助了本项目！ModelGo 是一个稳定、高效的企业级 AI API 聚合平台，一个 API Key 即可调用 Claude、OpenAI、Gemini、DeepSeek 等主流 AI 模型，帮助开发者和企业以更低成本快速构建 AI 应用。ModelGo 为本项目用户提供专属福利：注册即送 $0.5 试用额度，完成首次 API 调用再送 $2，邀请新用户额外获得 $1 奖励！ 平台还提供阶梯式消费返佣机制，用得越多，返得越多，畅享 AI 模型调用。此外，ModelGo 支持 SLA 服务保障、可视化监控面板等企业级功能，保障 API 调用稳定可靠，满足生产环境部署需求。立即访问 [ModelGo 官网](https://modelgo.ai/?utm_source=ppt-master&utm_medium=sponsorship&utm_content=readme02&campaign_id=ppt-master-github&ad_group_id=readme02) 注册体验，开启高效 AI 开发！

## 基础设施支持

<a href="https://m.do.co/c/547f129aabe1"><img src="https://opensource.nyc3.cdn.digitaloceanspaces.com/attribution/assets/PoweredByDO/DO_Powered_by_Badge_blue.svg" alt="Powered by DigitalOcean" height="40"></a>

感谢 [DigitalOcean](https://m.do.co/c/547f129aabe1) 为项目基础设施提供支持。

## 个人赞助

如果 PPT Master 帮到了你，任何金额的个人赞助都能帮助项目持续更新、保持免费开源。

<a href="https://paypal.me/hugohe3"><img src="https://img.shields.io/badge/PayPal-赞助-00457C?style=for-the-badge&logo=paypal&logoColor=white" alt="通过 PayPal 赞助"></a>

[支付宝收款码](https://raw.githubusercontent.com/hugohe3/ppt-master/main/docs/assets/alipay-qr.jpg)
